
revoke execute on function public.has_role(uuid, public.app_role) from public, anon, authenticated;
